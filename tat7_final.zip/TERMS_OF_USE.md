# Условия использования TreeAngleTap (TAT-7)

© 2026 Marat Sultanow. Все права защищены.

## Лицензии
- Код: MIT License
- Веса: CC BY-NC-ND 4.0

## Коммерческое использование
Запрещено без письменного разрешения автора.
Запрос: maratsultanov2@gmail.com

## Обязательное указание авторства
При любом использовании указывайте:
- Автор: Marat Sultanow
- Проект: TreeAngleTap (TAT-7)
- Ссылка: https://github.com/maratsultanov2/TreeAngleTap