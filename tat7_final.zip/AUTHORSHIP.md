# Декларация об авторстве

Я, Султанов Марат, заявляю, что являюсь единственным автором проекта TreeAngleTap (TAT-7).

## Доказательства
- 47 файлов диалогов с DeepSeek (январь-март 2026)
- GitHub: github.com/maratsultanov2/TreeAngleTap
- Публикация на Habr

## Контакты
- Email: maratsultanov2@gmail.com
- Telegram: @Marat_Sultanow

**Дата**: 30 марта 2026