# 🌳 TreeAngleTap (TAT-7)

[![License: MIT](https://img.shields.io/badge/Code-MIT-yellow.svg)](LICENSES/LICENSE_CODE.txt)
[![License: CC BY-NC-ND](https://img.shields.io/badge/Weights-CC%20BY--NC--ND-lightgrey.svg)](LICENSES/LICENSE_WEIGHTS.txt)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1ZAMW7NaNk4NqOQxPjSRJr_5i9OI6UpZR)

**83% на CIFAR-10 | 0.45M параметров | 3 мс на телефоне | 5 пирамид**

## 📌 О проекте

**TreeAngleTap (TAT-7)** — лёгкая нейросеть для классификации изображений, оптимизированная для мобильных устройств.
Архитектура — 5 пирамид. Ключевое открытие: HARMONY (связи) важнее SOLO (признаков) в 4 раза.

## 🧱 Архитектура: 5 пирамид

| Пирамида | Функция | Параметры |
|----------|---------|-----------|
| **Фильтр** | Разделяет признаки | SOLO=0.55, RHYTHM=0.43, HARMONY=2.0 |
| **Компрессор** | Сжимает данные | 1 слой, 128 нейронов |
| **Головы** | Параллельная обработка | 5 голов, 64 размерность |
| **Память** | Сохраняет контекст | T=0.7, энтропия=1.18 |
| **Вывод** | Классифицирует | 1x128_silu, dropout=0.3 |

## 📊 Результаты

| Датасет | Точность | Параметры | Скорость (телефон) |
|---------|----------|-----------|-------------------|
| CIFAR-10 | **83%** | 0.45M | 3–18 мс |
| MNIST | 97.42% | 0.45M | 3–5 мс |

## 🚀 Быстрый старт

```bash
pip install git+https://github.com/maratsultanov2/TreeAngleTap.git
```

```python
from treeangletap import TAT7
model = TAT7()
model.load_weights("weights/tat7_mobile.pt")
result = model.predict(image)
```

## 📜 Лицензии

| Компонент | Лицензия |
|-----------|----------|
| Код | MIT |
| Веса | CC BY-NC-ND 4.0 (некоммерческое) |
| Коммерческое использование | По запросу: maratsultanov2@gmail.com |

## 👤 Автор

Marat Sultanow, 2026